# wisconsin-card-sorting-test

wcst_gen_rule.py             # data generator modified to force feature rule\
model.py            # transformer build \
train.py            # main script for training and running eval \
model_v2.py            # transformer build with feature eng\
train_v2.py            # revised training for new model\

evaluate.py
evaluate_v2.py # handles new model eval

requirements.txt    # project dependencies \
README.md           